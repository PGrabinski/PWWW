<?php
 include 'head.php';
?>

<h1 class="alert alert-success">Welcome to the exercise 1!</h1>


<?php
  include 'tail.php';
  ?>
