<?php
  require 'head.php';
  ?>

        <h1 class="alert alert-success">Welcome to the exercise 2!</h1>


<?php
  require 'tail.php';
 ?>
