<?php require('./head.php');?>


    <div class="row">
      <div class="col-md-10 mx-auto">
        <div class="card card-body">
          <h2 class="card-title my-2 p-2">Godziny przyjęć</h2>
          <p class="card-text p-2">
            <hr>
          Nasi lekarze przyjmują od poniedziałku do piątku w godzinach od 8:00 do 22:00.
          <hr>
          By umówić się na wizytę, zapraszamy do kontaktu.
          </p>
        </div>
      </div>
    </div>

    <?php require('./tail.html');?>
