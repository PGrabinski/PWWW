<?php require('./head.php');?>


    <div class="row">
      <div class="col-md-6 ml-auto">
        <div class="card card-body">
          <h2 class="card-title my-2 p-2">Twoje oczy, Twoja przyszłość</h2>
          <p class="card-text p-2">
          Od roku 1991 działamy jako pierwszy prywatny ośrodek komplekosowo
           zajmujący się zdrowiem Państwa oczu.
          </p>
        </div>
      </div>
      <div class="col-md-4 mr-auto">
        <div class="card card-body">
        <img class="card-img img-thumbnail" src="http://www.kardiotel.pl/images/ilustracje/okulista.jpg" alt="Okulista">
        </div></div>
    </div>


    <?php require('./tail.html');?>
