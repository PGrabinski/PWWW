</div>
<script src="../../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<footer class="bg-dark fixed-bottom text-center text-light p-1 mt-5">
  Copyright &copy; Paweł Grabiński
</footer>
</body>

</html>
