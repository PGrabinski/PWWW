<!DOCTYPE html>

<html>

<head>
  <charset='utf-8'>
    <link href="../../node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css" type="text/css">
    <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.6/css/lightgallery.css" /> 
</head>

<body>
  <?php
   include 'menu.html';
  ?>
  <div id=main>
