<?php
 include 'head.php';
?>

<?php
echo '<h1 class="h1 mx-auto">Moje rodzinne miasto:</h1><br>';

echo '<iframe
  width="600"
  height="450"
  frameborder="0" style="border:0"
  src="https://www.google.com/maps/embed/v1/view?key=AIzaSyBNvcUaZ8G7zMsDniXBrU4BSMbd9EfTEio
  &center=50.849619,17.468607
  &zoom=13" allowfullscreen>
</iframe>';


?>


<?php
  include 'tail.php';
?>
